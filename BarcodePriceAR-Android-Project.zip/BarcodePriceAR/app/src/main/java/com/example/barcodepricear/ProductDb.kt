package com.example.barcodepricear

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject

data class Product(val barcode: String, val name: String, val price: Double, val updatedAt: Long)

class ProductDb(context: Context) : SQLiteOpenHelper(context, "prices.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE products(
            barcode TEXT PRIMARY KEY, name TEXT NOT NULL DEFAULT '',
            price REAL NOT NULL, updated_at INTEGER NOT NULL)""")
        db.execSQL("""CREATE TABLE price_history(
            id INTEGER PRIMARY KEY AUTOINCREMENT, barcode TEXT NOT NULL,
            name TEXT NOT NULL, old_price REAL, new_price REAL NOT NULL,
            changed_at INTEGER NOT NULL)""")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun get(barcode: String): Product? = readableDatabase.rawQuery(
        "SELECT barcode,name,price,updated_at FROM products WHERE barcode=?",
        arrayOf(barcode)
    ).use { c ->
        if (!c.moveToFirst()) null else Product(c.getString(0), c.getString(1), c.getDouble(2), c.getLong(3))
    }

    fun all(): List<Product> {
        val result = mutableListOf<Product>()
        readableDatabase.rawQuery("SELECT barcode,name,price,updated_at FROM products ORDER BY name COLLATE NOCASE, barcode", null).use { c ->
            while (c.moveToNext()) result.add(Product(c.getString(0), c.getString(1), c.getDouble(2), c.getLong(3)))
        }
        return result
    }

    fun save(barcode: String, name: String, price: Double) {
        val now = System.currentTimeMillis()
        val old = get(barcode)
        val values = ContentValues().apply {
            put("barcode", barcode); put("name", name.trim()); put("price", price); put("updated_at", now)
        }
        writableDatabase.beginTransaction()
        try {
            writableDatabase.insertWithOnConflict("products", null, values, SQLiteDatabase.CONFLICT_REPLACE)
            if (old == null || old.price != price || old.name != name.trim()) {
                val h = ContentValues().apply {
                    put("barcode", barcode); put("name", name.trim())
                    if (old == null) putNull("old_price") else put("old_price", old.price)
                    put("new_price", price); put("changed_at", now)
                }
                writableDatabase.insert("price_history", null, h)
            }
            writableDatabase.setTransactionSuccessful()
        } finally { writableDatabase.endTransaction() }
    }

    fun history(barcode: String): List<String> {
        val out = mutableListOf<String>()
        readableDatabase.rawQuery(
            "SELECT old_price,new_price,changed_at FROM price_history WHERE barcode=? ORDER BY changed_at DESC",
            arrayOf(barcode)
        ).use { c ->
            while (c.moveToNext()) {
                val old = if (c.isNull(0)) "بداية التسجيل" else MainActivity.money(c.getDouble(0)) + " دج"
                out.add("$old ← ${MainActivity.money(c.getDouble(1))} دج\n${java.text.SimpleDateFormat("yyyy/MM/dd HH:mm", java.util.Locale.getDefault()).format(java.util.Date(c.getLong(2)))}")
            }
        }
        return out
    }

    fun exportJson(): String {
        val root = JSONObject()
        val products = JSONArray()
        for (p in all()) {
            products.put(JSONObject().put("barcode", p.barcode).put("name", p.name)
                .put("price", p.price).put("updatedAt", p.updatedAt))
        }
        val hist = JSONArray()
        readableDatabase.rawQuery("SELECT barcode,name,old_price,new_price,changed_at FROM price_history ORDER BY changed_at", null).use { c ->
            while (c.moveToNext()) {
                val o = JSONObject().put("barcode", c.getString(0)).put("name", c.getString(1))
                    .put("newPrice", c.getDouble(3)).put("changedAt", c.getLong(4))
                if (!c.isNull(2)) o.put("oldPrice", c.getDouble(2))
                hist.put(o)
            }
        }
        return root.put("formatVersion", 1).put("products", products).put("history", hist).toString(2)
    }

    fun importJson(json: String) {
        val root = JSONObject(json)
        val products = root.getJSONArray("products")
        writableDatabase.beginTransaction()
        try {
            for (i in 0 until products.length()) {
                val o = products.getJSONObject(i)
                val values = ContentValues().apply {
                    put("barcode", o.getString("barcode")); put("name", o.optString("name", ""))
                    put("price", o.getDouble("price")); put("updated_at", o.optLong("updatedAt", System.currentTimeMillis()))
                }
                writableDatabase.insertWithOnConflict("products", null, values, SQLiteDatabase.CONFLICT_REPLACE)
            }
            val hist = root.optJSONArray("history") ?: JSONArray()
            for (i in 0 until hist.length()) {
                val o = hist.getJSONObject(i)
                val values = ContentValues().apply {
                    put("barcode", o.getString("barcode")); put("name", o.optString("name", ""))
                    if (o.has("oldPrice")) put("old_price", o.getDouble("oldPrice")) else putNull("old_price")
                    put("new_price", o.getDouble("newPrice")); put("changed_at", o.optLong("changedAt", System.currentTimeMillis()))
                }
                writableDatabase.insert("price_history", null, values)
            }
            writableDatabase.setTransactionSuccessful()
        } finally { writableDatabase.endTransaction() }
    }
}
