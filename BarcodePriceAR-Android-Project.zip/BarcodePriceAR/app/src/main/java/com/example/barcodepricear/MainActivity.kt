package com.example.barcodepricear

import android.Manifest
import android.app.AlertDialog
import android.content.ContentValues
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var db: ProductDb
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private var cameraProvider: ProcessCameraProvider? = null
    private var scanning = false
    private var lastCodeAt = 0L

    private val exportLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) try {
            contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(db.exportJson()) }
            toast("تم تصدير النسخة الاحتياطية")
        } catch (e: Exception) { toast("تعذر حفظ النسخة: ${e.message}") }
    }
    private val importLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) AlertDialog.Builder(this).setTitle("استرجاع النسخة")
            .setMessage("سيتم دمج المنتجات الموجودة مع النسخة المختارة. هل تريد المتابعة؟")
            .setNegativeButton("إلغاء", null).setPositiveButton("استرجاع") { _, _ ->
                try {
                    val json = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                        ?: throw IllegalStateException("تعذر قراءة الملف")
                    db.importJson(json); toast("تم استرجاع البيانات"); showList()
                } catch (e: Exception) { toast("ملف غير صالح: ${e.message}") }
            }.show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = ProductDb(this)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setBackgroundColor(0xFFF5F7F5.toInt())
        }
        setContentView(root)
        showHome()
    }

    private fun showHome() {
        stopCamera()
        base("أثمان الباركود")
        addText("سجّل أثمان منتجاتك وارجع ليها بلا إنترنت", 15, 0xFF52635B.toInt())
        addButton("📷  مسح باركود بالكاميرا") { startScannerScreen() }
        addButton("📦  لائحة المنتجات والأثمنة") { showList() }
        addButton("⬆  تصدير نسخة احتياطية") { exportLauncher.launch("athman-backup.json") }
        addButton("⬇  استرجاع نسخة احتياطية") { importLauncher.launch(arrayOf("application/json", "text/*", "*/*")) }
        addText("عدد المنتجات المسجلة: ${db.all().size}", 14, 0xFF176B55.toInt())
        addText("مهم: احتفظ بنسخة احتياطية خارج الهاتف بشكل دوري.", 13, 0xFF805B1B.toInt())
    }

    private fun startScannerScreen() {
        base("مسح الباركود")
        status = addText("وجّه الكاميرا نحو الباركود", 16, 0xFF176B55.toInt())
        val previewView = PreviewView(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
        root.addView(previewView)
        addButton("إيقاف المسح والرجوع") { showHome() }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestCamera.launch(Manifest.permission.CAMERA)
            return
        }
        bindCamera(previewView)
    }

    private val requestCamera = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startScannerScreen() else { toast("خاص السماح باستعمال الكاميرا"); showHome() }
    }

    private fun bindCamera(previewView: PreviewView) {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                cameraProvider = provider
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val analysis = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
                val scanner = BarcodeScanning.getClient()
                analysis.setAnalyzer(cameraExecutor) { proxy ->
                    val media = proxy.image
                    if (media == null) { proxy.close(); return@setAnalyzer }
                    val image = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
                    scanner.process(image)
                        .addOnSuccessListener { barcodes ->
                            val code = barcodes.firstOrNull { !it.rawValue.isNullOrBlank() }?.rawValue
                            if (code != null && System.currentTimeMillis() - lastCodeAt > 1800) {
                                lastCodeAt = System.currentTimeMillis()
                                runOnUiThread { openProduct(code) }
                            }
                        }
                        .addOnCompleteListener { proxy.close() }
                }
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
            } catch (e: Exception) { toast("تعذر تشغيل الكاميرا: ${e.message}") }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun openProduct(code: String) {
        stopCamera()
        val product = db.get(code)
        val nameInput = EditText(this).apply { hint = "اسم المنتج"; setText(product?.name ?: "") }
        val priceInput = EditText(this).apply {
            hint = "الثمن بالدينار الجزائري"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            if (product != null) setText(product.price.toString())
        }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0)
            addView(TextView(this@MainActivity).apply { text = "الباركود: $code"; textSize = 14f })
            addView(nameInput); addView(priceInput)
        }
        val dialog = AlertDialog.Builder(this).setTitle(if (product == null) "منتج جديد" else "الثمن المسجل")
            .setView(layout).setNegativeButton("رجوع للمسح") { _, _ -> startScannerScreen() }
            .setNeutralButton("تاريخ الثمن") { _, _ -> showHistory(code) }
            .setPositiveButton("حفظ الثمن") { _, _ ->
                val price = priceInput.text.toString().trim().replace(',', '.').toDoubleOrNull()
                if (price == null || price < 0) { toast("دخل ثمن صحيح"); startScannerScreen() }
                else {
                    db.save(code, nameInput.text.toString(), price)
                    AlertDialog.Builder(this).setTitle("تم الحفظ")
                        .setMessage("${nameInput.text} \n${money(price)} دج")
                        .setPositiveButton("مسح منتج آخر") { _, _ -> startScannerScreen() }
                        .setNegativeButton("الرئيسية") { _, _ -> showHome() }.show()
                }
            }.create()
        dialog.setOnDismissListener { }
        dialog.show()
    }

    private fun showHistory(code: String) {
        val entries = db.history(code)
        AlertDialog.Builder(this).setTitle("تاريخ تغييرات الثمن")
            .setMessage(if (entries.isEmpty()) "لا يوجد تاريخ بعد" else entries.joinToString("\n\n"))
            .setPositiveButton("إغلاق", null).show()
    }

    private fun showList() {
        stopCamera()
        base("لائحة المنتجات")
        val search = EditText(this).apply { hint = "بحث بالاسم أو الباركود" }
        root.addView(search)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this); scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        fun refresh(query: String = "") {
            list.removeAllViews()
            db.all().filter { it.name.contains(query, true) || it.barcode.contains(query, true) }.forEach { p ->
                val card = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(10))
                    setBackgroundColor(0xFFFFFFFF.toInt())
                }
                card.addView(TextView(this).apply { text = if (p.name.isBlank()) "منتج بلا اسم" else p.name; textSize = 18f; setTextColor(0xFF174B3B.toInt()) })
                card.addView(TextView(this).apply { text = "${money(p.price)} دج"; textSize = 20f; setTextColor(0xFF176B55.toInt()) })
                card.addView(TextView(this).apply { text = "الباركود: ${p.barcode}"; textSize = 12f })
                card.setOnClickListener { openProduct(p.barcode) }
                list.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
            }
            if (list.childCount == 0) list.addView(TextView(this).apply { text = "ما كاين حتى منتج مسجل"; setPadding(8, 20, 8, 20) })
        }
        search.addTextChangedListener(SimpleTextWatcher { refresh(it) })
        refresh()
        addButton("رجوع للرئيسية") { showHome() }
    }

    private fun base(title: String) {
        root.removeAllViews()
        val heading = TextView(this).apply {
            text = title; textSize = 24f; setTextColor(0xFF104B3B.toInt())
            gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(16))
        }
        root.addView(heading)
    }
    private fun addText(text: String, size: Int, color: Int): TextView {
        val v = TextView(this).apply { this.text = text; textSize = size.toFloat(); setTextColor(color); setPadding(0, dp(8), 0, dp(8)) }
        root.addView(v); return v
    }
    private fun addButton(text: String, action: () -> Unit) {
        val b = com.google.android.material.button.MaterialButton(this).apply {
            this.text = text; isAllCaps = false; textSize = 16f
            setOnClickListener { action() }
        }
        root.addView(b, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
    }
    private fun stopCamera() { try { cameraProvider?.unbindAll() } catch (_: Exception) {} }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    override fun onDestroy() { super.onDestroy(); stopCamera(); cameraExecutor.shutdown() }
    companion object {
        fun money(value: Double): String = String.format(Locale("ar", "DZ"), "%,.2f", value)
    }
}

private class SimpleTextWatcher(val changed: (String) -> Unit) : android.text.TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { changed(s?.toString() ?: "") }
    override fun afterTextChanged(s: android.text.Editable?) {}
}
